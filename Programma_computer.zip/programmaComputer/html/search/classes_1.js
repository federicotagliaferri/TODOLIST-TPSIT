var searchData=
[
  ['magazzino_22',['Magazzino',['../class_magazzino.html',1,'']]]
];
