var searchData=
[
  ['ricercacodice_39',['ricercaCodice',['../class_magazzino.html#aa873dba4a25f9d0dc8733c701d3a533d',1,'Magazzino']]],
  ['ricercamiglioredimensione_40',['ricercaMiglioreDimensione',['../class_magazzino.html#a2b32555cdd37f4e95e4467b28307e708',1,'Magazzino']]],
  ['ricercamiglioredisco_41',['ricercaMiglioreDisco',['../class_magazzino.html#a90ac7070eecfd144ee19892e8627b3bd',1,'Magazzino']]],
  ['ricercamigliorevelocita_42',['ricercaMiglioreVelocita',['../class_magazzino.html#ab54a9b1330c94ee464cc0ca79d261105',1,'Magazzino']]]
];
