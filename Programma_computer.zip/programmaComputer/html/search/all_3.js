var searchData=
[
  ['getanno_4',['getAnno',['../class_computer.html#a266e804a505ef62a52d392fb97136295',1,'Computer']]],
  ['getcodice_5',['getCodice',['../class_computer.html#af35011cc6acc86dfedc8b552aaefcc76',1,'Computer']]],
  ['getdisco_6',['getDisco',['../class_computer.html#a423c5c45f026004ba4d303f1d699d4d3',1,'Computer']]],
  ['getmarca_7',['getMarca',['../class_computer.html#aa6bad96b58eb5dbe24a4e883329e4f27',1,'Computer']]],
  ['getmodello_8',['getModello',['../class_computer.html#ad279d27889f3a2be9d74a4d5100786d2',1,'Computer']]],
  ['getpollici_9',['getPollici',['../class_computer.html#ad7671c74b6e92796765efec8e0d557ee',1,'Computer']]],
  ['getram_10',['getRam',['../class_computer.html#a9d53bb8cd3d722c233231c4541a88150',1,'Computer']]],
  ['getvel_11',['getVel',['../class_computer.html#ad4ef009c36dd475283abebf8cad23f37',1,'Computer']]]
];
