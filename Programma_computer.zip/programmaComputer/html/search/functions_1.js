var searchData=
[
  ['computer_27',['Computer',['../class_computer.html#aa969442430d5a7b89c1ed0812c9456d0',1,'Computer']]]
];
