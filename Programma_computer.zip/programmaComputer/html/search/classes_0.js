var searchData=
[
  ['computer_21',['Computer',['../class_computer.html',1,'']]]
];
