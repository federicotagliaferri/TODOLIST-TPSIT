var searchData=
[
  ['magazzino_12',['Magazzino',['../class_magazzino.html',1,'Magazzino'],['../class_magazzino.html#a37bffde449de9bfff667fc70dee06414',1,'Magazzino::Magazzino()']]],
  ['magazzino_2eh_13',['Magazzino.h',['../_magazzino_8h.html',1,'']]],
  ['main_14',['main',['../programma_computer_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'programmaComputer.cpp']]]
];
