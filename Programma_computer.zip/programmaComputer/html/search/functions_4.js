var searchData=
[
  ['magazzino_37',['Magazzino',['../class_magazzino.html#a37bffde449de9bfff667fc70dee06414',1,'Magazzino']]],
  ['main_38',['main',['../programma_computer_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'programmaComputer.cpp']]]
];
