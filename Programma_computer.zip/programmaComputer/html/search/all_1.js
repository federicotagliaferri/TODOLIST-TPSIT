var searchData=
[
  ['computer_1',['Computer',['../class_computer.html',1,'Computer'],['../class_computer.html#aa969442430d5a7b89c1ed0812c9456d0',1,'Computer::Computer()']]],
  ['computer_2eh_2',['Computer.h',['../_computer_8h.html',1,'']]]
];
