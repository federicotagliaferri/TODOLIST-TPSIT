var searchData=
[
  ['elimina_3',['elimina',['../class_magazzino.html#a9b77d6c56acfcb36b1705be5ab80bace',1,'Magazzino']]]
];
