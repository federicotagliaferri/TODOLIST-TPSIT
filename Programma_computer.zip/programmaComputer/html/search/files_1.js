var searchData=
[
  ['magazzino_2eh_24',['Magazzino.h',['../_magazzino_8h.html',1,'']]]
];
