var searchData=
[
  ['computer_2eh_23',['Computer.h',['../_computer_8h.html',1,'']]]
];
